<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Post;
use Mail;
use Session;

class PageController extends Controller
{

    public function getTerms() {
        return view('shop.terms');
    } 

    public function getDelivery() {
        return view('shop.delivery');
    }

    public function getHome() {
        return view('shop.home');
    }

    public function getAbout() {
        return view('shop.about');
    }

    public function getContact() {
        return view('shop.contact');
    }

    public function getAtraments() {
        return view('shop.atraments');
    }
	
	public function getPiezo() {
        return view('shop-products.piezo');
    }

    public function getThermalHead() {
        return view('shop-products.thermal-head');
    }
	public function getSubpiezo() {
        return view('shop-products.subpiezo');
    }

  
/*
    public function getPiezoPage() {
        return view('shop-products.piezo');
    }  */
	
	public function postContact(Request $request){
		$this->validate($request, [
		'subject' => 'min:3',
		'message' => 'min:10',
		'email' => 'required|email']);
		
		$data = array(
		'name' => $request->username,
		'email' => $request->email,
		'phoneNumber' => $request->phoneNumber,
		'subject' => $request->subject,
		'bodyMessage' => $request->message
		);
		
		Mail::send('emails.contact', $data, function($message)use($data){
			$message->from($data['email']);
			$message->to('danielbuzderewicz@gmail.com');
			$message->subject($data['subject']);
			
		});
		
		Session::flash('success', 'Your Email was sent');
		return redirect('/contactSuccess');
		
    }
    public function getContactSuccess() {
        return view('shop.contact-success');
    }
	public function getOrder() {
		return view('shop.order');
    }
	
}

