<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Product;
use App\ProductAtr;
use App\Cats;
use Session;
use App\Cart;


use App\Http\Requests;

class ProductController extends Controller
{
  /*  public function getIndexPiezo(){
        $products = ProductAtr::paginate(15);
        //return view('shop-products.piezo', compact('atraments');  
		return view('shop-products.prods', ['atraments' => $products]);
		//laravel makes new variable products / atraments to use in view
    } */
    
	public function proCat(Request $request){
		$cat = $request->cat;
		//'id' = 'product_atrs'->id;
		$products = DB::table('product_atrs')/*->join('cats', 'cats.id', 'product_atrs.cat_id')*/
		/*->where('cats.cat_name', $cat)*/->where('product_atrs.cat_id', $cat)->paginate(15);
		return view('shop-products.prods', [
		'atraments' => $products, 'catByUser' => $cat
		]);
	}

    public function getIndexTHencad(){
        $productsE = Encad::paginate(15);
        //return view('shop-products.piezo', compact('atraments');     
        return view('subcategories.th-encad', ['encad_atraments' => $productsE]);
        //laravel makes new variable products / atraments to use in view
    }
    

    public function getAddToCart(Request $request, $id) {
       $product = ProductAtr::find($id);
       $oldCart = Session::has('cart') ? $request->session()->get('cart') : null;
       $cart = new Cart($oldCart);
       $cart->add($product, $product->id);

       $request->session()-> put('cart', $cart);
       return redirect()->back(); 
    }

    public function getReduceByOne(Request $request, $id) {
        $oldCart = Session::has('cart') ? $request->session()->get('cart') : null;
        $cart = new Cart($oldCart);
        $cart->reduceByOne($id);
		
		if (count($cart->items) > 0){
			Session::put('cart', $cart);
		}else{
			Session::forget('cart');
		}
        return redirect()->route('product.shoppingCart');
    }
	
	public function getRemoveItem($id){
		$oldCart = Session::has('cart') ? Session::get('cart') : null;
		$cart = new Cart($oldCart);
		$cart->removeItem($id);
		
		if (count($cart->items) > 0){
			Session::put('cart', $cart);
		}else{
			Session::forget('cart');
		}
		return redirect()->route('product.shoppingCart');
	}

    public function getCart() {
       if (!Session::has('cart')) {
        return view('shop.shopping-cart');
       }
       $oldCart = Session::get('cart');
       $cart = new Cart($oldCart);
       return view('shop.shopping-cart', ['products' => $cart->items, 
       'totalPrice' => $cart->totalPrice]); 
    }

    
}
