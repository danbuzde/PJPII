<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\TabService;

class TabServiceController extends Controller
{
    public function servicePage()
    {
        $serve = TabService::all();

        return view('shop-products.piezo-services')->with(['serve' => $serve]);
    }
}
