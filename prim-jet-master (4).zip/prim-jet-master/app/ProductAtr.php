<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductAtr extends Model
{
    protected $fillable = ['title', 'color', 'quantity', 'price', 'category'];//fields to set while creating a new product
    
    public function cats(){
		return $this->belongsTo('App\Cats', 'cat_id');
	}	
}
