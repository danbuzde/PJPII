<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TabService extends Model
{
    protected $table = "tab_services";
}
