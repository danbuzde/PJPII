<?php

use Illuminate\Database\Seeder;

class AtramentsEpsonTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       // Model::unguard();

        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 130.00,
            'cat_id' => 1			
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1	
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1	
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
		
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Cyan',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Black',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Black',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4000-4400-7400-7600-9400-9600-10600',
            'color' => 'Light Black',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Cyan',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Black',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Black',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Black',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Light Black',
            'quantity' => '1 kg',
            'price' => 130.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Light Black',
            'quantity' => '500 g',
            'price' => 78.00,
			'cat_id' => 1
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy EPSON 4800-7800-9800-10800',
            'color' => 'Light Light Black',
            'quantity' => '250 g',
            'price' => 47.00,
			'cat_id' => 1
        ]);
        $product_atr->save();



        /************** UV BLOKER  *****************/

       
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Cyan',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 96,
			'cat_id' => 2
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Barwnikowy z UV blokerem do każdego plotera EPSON',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 58,
			'cat_id' => 2
        ]);
        $product_atr->save();
        

        /*ENCAD */
       
        $product_atr = new \App\ProductAtr([ 
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([ 
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 3
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([  
            'title' => 'Archiwalny barwnikowy Encad',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 3
        ]);
        $product_atr->save();
		
		/* DESIGNJET */
		
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
		]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
		
		$product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Lighy Cyan',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Orange',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Orange',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Orange',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Green',
            'quantity' => '1 kg',
            'price' => 150,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Green',
            'quantity' => '500 g',
            'price' => 90,
			'cat_id' => 4
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy HP DesignJet',
            'color' => 'Green',
            'quantity' => '250 g',
            'price' => 54,
			'cat_id' => 4
        ]);
        $product_atr->save();
		
		/* CANON IPF */
        
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
		$product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Cyan',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Red',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Red',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Red',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Green',
            'quantity' => '1 kg',
            'price' => 160,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Green',
            'quantity' => '500 g',
            'price' => 100,
			'cat_id' => 5
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Barwnikowy CANON IPF',
            'color' => 'Green',
            'quantity' => '250 g',
            'price' => 60,
			'cat_id' => 5
        ]);
        $product_atr->save();
		
		
		/* SUBLIMACYJNY PIEZO HQ */
        
		
		$product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Black',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Black',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Black',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Black',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Cyan',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Cyan',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Cyan',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Cyan',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Magenta',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Magenta',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Magenta',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Magenta',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();
		$product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Yellow',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Yellow',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Yellow',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Yellow',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Cyan',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Cyan',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Cyan',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Cyan',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Magenta',
            'quantity' => '1 kg',
            'price' => 220,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Magenta',
            'quantity' => '500 g',
            'price' => 132,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Magenta',
            'quantity' => '250 g',
            'price' => 79,
			'cat_id' => 6
        ]);
        $product_atr->save();
        $product_atr = new \App\ProductAtr([   
            'title' => 'Sublimacyjny Piezo HQ',
            'color' => 'Light Magenta',
            'quantity' => '100 g',
            'price' => 32,
			'cat_id' => 6
        ]);
        $product_atr->save();


    }
}
