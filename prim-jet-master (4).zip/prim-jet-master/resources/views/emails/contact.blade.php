<h3>Masz nową wiadomość z formularza kontaktowego</h3>

<div>
{{ $bodyMessage }}

<p>{{ $name }}</p>
<p>Numer telefonu: {{$phoneNumber}}</p>
</div>

<p>Wysłano z adresu {{ $email }}</p>