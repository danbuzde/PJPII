<footer> 

		<div class="copy"> &copy; Prim Jet Color 2017 </div> 
		<ul> 
			<li><a href="{{ route('terms') }}"> Regulamin   </a></li>
			<li><a href="{{ route('delivery') }}"> Wysyłka i Płatność   </a></li>
		</ul>

</footer>