<header>
    
	<div class="nav-container">
		<nav> 
			<ul class="main"> 
				<a href="{{ route('home') }}"><li> Home  </li></a>
				<a href="{{ route('about') }}"> <li>O firmie  </li></a>
				<li><a href="#" class="arrowlink" aria-haspopup="true"> Sklep </a>

					<ul> 
						<a href="#"><li>  Płynne laminaty </li></a> 
						<a href="#"><li> Lakiery podkładowe  </li></a>
						<a href="#"><li>  Płyny czyszczące </li></a> 
						<a href="{{ route('atraments') }}"><li>  Atramenty </li></a> 
					</ul>
				</li> 
				<a href="{{ route('contact') }}"><li> Kontakt  </li></a>
			</ul>
		</nav>
		
		<div class="search"> </div>
        <div class="cart"> 
            <a href="{{ route('product.shoppingCart') }}" class="cart-link"> 
                <div id="number" class="cart-number">{{ Session::has('cart') ? Session::get('cart')->totalQty : "" }}</div>
                 <img class="cart-bg" src="/img/icons/cart48.png"> <img class="cart-sm" src="/img/icons/cart32.png"> 
            </a>
		</div>
		<div class="logo"><a href="{{ route('home') }}"><strong> Prim Jet Color</strong> </br>
            <span> <a href="{{ route('atraments') }}"> atramenty </a>  |  <a href="#"> lakiery </a> </span> </a> 
        </div>
	</div>	
		
</header>