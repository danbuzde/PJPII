<!-- NIE WIEM CO TO -->

@section('tab-content')

<ul class="nav nav-tabs">
@foreach($serve as $count => $serves)
      <li class="active"><a href="#tab-{{ $serves->id }}" aria-controls="#tab-{{$serves->id}}" data-toggle="tab">{{ $serves->service }}</a></li>
    
</ul>

<div class="row">
    <article class="col-lg-12">
        <div class="tab-content">
        @foreach($serve as $count => $serves)
            <div role="tabpanel" @if($count == 0) class="tab-pane fade show active" 
            @else class="tab-pane" @endif id="tab-{{ $serves->id }}">
                <h2> {{ $serves -> service </h2>
            
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
                        @foreach($atraments as $product_atr) 
                                <tr>
                                    <td>
                                        <h4>{{ $product_atr->title}}</h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->color}} </h4> 
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->quantity}} </h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->price}}zł </h4>
                                    </td>
                                    <td> 
                                        <a href="{{ route('product.addToCart', ['id'=>$product_atr->id]) }}" class="order"> 
                                        <img class="add-cart-bg" src="img/icons/cart48.png"> <img class="add-cart-sm" src="img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
                        @endforeach   
            
                            </tbody>     
                        </table>
                    </div>
                    
                </div>
                @endforeach
            </div>
        </article>
    </div>

    <div class="my-pagin">
        {!! $atraments -> links('vendor.pagination.bootstrap-4'); !!}
    </div>


@endsection