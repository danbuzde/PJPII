@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <link rel="stylesheet" href="/css/bootstrap/css/bootstrap.min.css" type="text/css">  
    <link rel="stylesheet" href="/css/style.css" type="text/css"> 
	<link rel="stylesheet" href="/css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="/css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="/css/responsive.css" type="text/css"> 
    
    
	

@endsection

@section('content')
<!-- piezo content section was here -->
                @if(count($atraments)=="0")
				<h1>Nie znaleziono produktów z kategorii {{$catByUser}} </h1>
				@else
				<h2> {{$catByUser}} </h2>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
							
                        @foreach($atraments as $product_atr) 
						
                                <tr>
                                    <td>
                                        <h4>{{ $product_atr->title}}</h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->color}} </h4> 
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->quantity}} </h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atr->price}}zł </h4>
                                    </td>
									<td> 
                                        <a href="{{ route('product.addToCart', ['id'=>$product_atr->id]) }}" class="order"> 
                                        <img class="add-cart-bg" src="/img/icons/cart48.png"> <img class="add-cart-sm" src="/img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
						@endforeach
                    @endif						
							
                            </tbody>     
                        </table>
                    </div>
           
<!--
    <div class="row">
    <article class="col-lg-12">
        <div class="tab-content">
            <div class="tab-pane fade" id="epsonUV">
                <h2> Do ploterów EPSON z UV blokerem</h2>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
                        @foreach($atraments as $product_atrUV) 
                                <tr>
                                    <td>
                                        <h4>{{ $product_atrUV->title}}</h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atrUV->color}} </h4> 
                                    </td>
                                    <td>
                                        <h4>{{ $product_atrUV->quantity}} </h4>
                                    </td>
                                    <td>
                                        <h4>{{ $product_atrUV->price}}zł </h4>
                                    </td>
                                    <td> 
                                        <a href="{{ route('product.addToCart', ['id'=>$product_atrUV->id]) }}" class="order"> 
                                        <img class="add-cart-bg" src="img/icons/cart48.png"> <img class="add-cart-sm" src="img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
                        @endforeach   
            
                            </tbody>     
                        </table>
                    </div>
                </div>
            </div>
        </article>
    </div> -->

    <div class="my-pagin">
        {!! $atraments -> links('vendor.pagination.bootstrap-4'); !!}
    </div>



</section>


@endsection

@section('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script>
      $(function () {
      $('.nav-tabs a:first').tab('show')
      })
</script>

@endsection