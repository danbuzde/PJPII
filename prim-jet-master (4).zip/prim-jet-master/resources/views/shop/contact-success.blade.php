@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
    <link rel="stylesheet" href="css/contact.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
    
@endsection

@section('content')

<section>
<div class="contact-container">

	<div class="contact-wrapper">	

		<h1> Kontakt </h1>

			<div class="contact-info"> 
				<span class="contact-name"> Prim Jet Color Sp z o.o. </span> </br>
				Nr tel: (48) (58) 719 14 58 lub 694 485 805</br>
				Nr konta: 33 9823 2844 3782 6453 </br>
			</div>

            <div class="contact-info">
                <h3> Twoja wiadomość została wysłana pomyślnie. Dziękujemy!</h3>
            </div>
    </div> <!--End of contact-wrapper -->
</div>
</section>

@endsection