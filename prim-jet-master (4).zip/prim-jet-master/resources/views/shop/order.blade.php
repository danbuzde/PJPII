@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
    <link rel="stylesheet" href="css/contact.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
    
@endsection

@section('content')

@if(Session::has('cart'))
<section>
<div class="contact-container">

	<div class="contact-wrapper">	
        
		<h3> Informacje do wysyłki. Uzupełnij pola prawdziwymi danymi. </h3>			

		<form id="contact-form" action=" {{ route('order') }} " method="POST">
			{{ csrf_field() }}
            

			<label for="name"> Imię  </label> 
			<input type="text" id="name" autocomplete="off" placeholder="Imię" name="name">

            <label for="last-name">Nazwisko  </label> 
			<input type="text" id="lastname" autocomplete="off" placeholder="Nazwisko" name="lastname">

			<label for="email"> Adres e-mail </label> 
			<input type="text" id="email" autocomplete="off" placeholder="Adres e-mail" name="email">

            <label for="phoneNumber"> Numer telefonu </label> 
            <input type="number" id="phoneNumber" autocomplete="off" placeholder="Nr telefonu" name="phoneNumber">

			<label for="address"> Adres </label> 
			<input type="text" id="address" autocomplete="off" placeholder="Adres" name="">

            <label for="address"> Miasto </label> 
			<input type="text" id="city" autocomplete="off" placeholder="Miasto" name="">

            <label for="address"> Kod pocztowy </label> 
            <input type="text" autocomplete="off" placeholder= "Kod pocztowy" pattern= "[0-9]{2}\-[0-9]{3}" />            

			<label for="message"> Dodatkowe informacje </label> 
			<textarea name="message" id="message" autocomplete="off" rows="4"> </textarea>

            <div class="contact-info"> 
                <p> Koszt zamówienia: <b>  zł </b></p>
                <p> Koszt przesyłki: <b> 25zł </b> </p>
                
                <h4>Dodatkowe usługi płatne:</h4>
                <div>
                    <p><input type="checkbox" id="nextDay12" name="additionals[]" value="nextDay12"> Dostarczenie następnego dnia do 12:00 - 30zł </p>
                </div>
                <div>
                    <p> <input type="checkbox" id="saturday" name="additionals[]" value="saturday">
                    Dostarczenie w sobotę - 15zł</p>
                </div>
                <div>
                    <p> <input type="checkbox" id="sundayHoliday" name="additionals[]" value="sundayHoliday">
                    Dostarczenie w niedzielę lub święto - 30zł</p>
                </div>
                <div>
                    <p><input type="checkbox" id="docsReturn" name="additionals[]" value="docsReturn">
                    Zwrot dokumentów załączonych do przesyłki - 10zł</p>
                </div>
                <div>
                    <p><input type="checkbox" id="writtenDeliveryConfirmation" name="additionals[]" value="writtenDeliveryConfirmation">
                    Pisemne potwierdzenie dostawy - 5zł</p>
                </div>
                
            </div>

            <div class="contact-info">
                <h4>Sposób płatności </h4>
                <select name="payment" form="payment">
                    <option value="transfer">Przelew</option>
                    <option value="onDelivery">Za pobraniem</option>
                    <option value="payPal">PayPal</option>
                    
                </select>
            </div>

            <div class="contact-info">
                <h3> Koszt całkowity: zł </h3>
            </div>

			<input class="btn default" type="submit" id="submit" value="Zamawiam"> 
        </form>
        

	</div> <!--End of contact-wrapper -->

</div>
</section>
@endif
@endsection