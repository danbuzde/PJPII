@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" 
    integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" 
    crossorigin="anonymous"> -->
    <link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 

@endsection

@section('content')


@if(Session::has('cart'))
<div class="cart-container">
    <div class="cart-wrapper">

        <div class="cart-header">
            <h1>Twój koszyk</h1>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Rodzaj plotera</th>
                        <th>Kolor</th>
                        <th>Pojemność </th>
                        <th>Ilość</th>
                        <th>Cena</th>    
                                                     
                    </tr>
                </thead>
    
                <tbody>
                @foreach($products as $product) 
                    <tr>
                        <td>
                            <h4>{{ $product['item']['title']  }}</h4>
                        </td>
                        <td>
                            <h4>{{ $product['item']['color'] }} </h4> 
                        </td>
                        <td>
                            <h4>{{ $product['item']['quantity'] }} </h4>
                        </td>
                        <td>
                            <h4>{{ $product['qty'] }} </h4>
                        <td>
                            <h4>{{ $product['price'] }} zł </h4>
                        </td>
                        <td>
                          <div class="btn-delete">
                            <ul class="delete-items"> 
                                <li><a href="{{ route('product.reduceByOne', 
                                            ['id' => $product['item']['id']]) }}"> Usuń jedną sztukę </a></li>
                                     
                            </ul>
                            </div>
                        </td>
						<td>
                          <div class="btn-delete">
                            <ul class="delete-items"> 
                                <li><a href="{{ route('product.remove', 
                                            ['id' => $product['item']['id']]) }}"> Usuń wszystkie </a></li>
                                     
                            </ul>
                            </div>
                        </td>
                                    
                    </tr> 
                    @endforeach   
            
                </tbody>     
            </table>
        </div>


<!--


            ////////
            <div id="cart-items">          
                    <ul class="items-list">

                    @foreach($products as $product)
                        <li class="cart-item first">    
                            <div class="image">                           
                                <img src="{{ $product['item']['imagePath'] }}" alt="ikona">
                            </div>                                                    
                                                                      
                            <div class="order-summary">
                                <span class="title"><strong> Tytuł: </strong> "{{ $product['item']['title']  }}" </span><br>
                                <span class="amount"><strong> Ilość: </strong> {{ $product['qty'] }} </span> <br>
                                <span class="size"> <strong> Cena: </strong> {{ $product['price'] }} zł </span> <br>                              
                            </div>
                            
                            <div class="delete-btn">
                                    <select class="delete-items" name="delete-items"> 
                                        <option value="delete1"><a href="{{ route('product.reduceByOne', 
                                            ['id' => $product['item']['id']]) }}"> Usuń jedną sztukę </a></option>
                                        <option value="delete-all"> Usuń wszystko </option>            
                                    </select>
                            </div>
                        </li>
      
                    @endforeach
                    </ul>          
            </div> end od cart-items-->

            <div id="total" class="cart-totals">
                <h2>Razem: {{ $totalPrice  }} zł</h2>
                <div id="total-amount"> </div>
            </div>
            <div class="payment">
                <a href="{{ route('order') }}"> <button type="button" class="btn" value="order"> 
                    Zamawiam </button> 
                </a> 
            </div>
                    </div> <!-- end od cart-wrapper-->
    </div> <!-- end od cart-container-->


    @else 
    <div class="cart-container">
        <div class="cart-wrapper">

            <h2 class="empty-cart">Twój koszyk jest pusty. </h2>
            
        </div> <!-- end od cart-wrapper-->
    </div> <!-- end od cart-container-->


    @endif



<!-- 
    @if(Session::has('cart'))
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <ul class="list-group">
                    @foreach($products as $product)
                        <li class="list-group-item"> 
                            <span class="badge"> {{ $product['qty'] }} </span>  floats to the right 
                            <strong> {{ $product['item']['title']  }} </strong>
                            <span class="label label-success"> {{ $product['price'] }} </span>


                            <div class="btn-group"> 
                                <button class="btn btn-primary btn-xs dropdown-toggle" data-toggle="dropdown"> 
                                    Zredukuj <span class="caret">  </span>
                                </button>
                                <ul class="dropdown-menu"> 
                                    <li><a href="#"> Usuń jeden element </a> </li>
                                    <li><a href="#"> Usuń wszystko </a> </li>
                                    
                                </ul>
                            </div>


                        </li>
                    @endforeach
                </ul>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <strong> Razem: {{ $totalPrice  }} </strong>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
            <button type="button" class="btn" value="order">Zamawiam</button> 
            </div>
        </div>


    @else 
        <div class="row">
            <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                <h2> Twój koszyk jest pusty </h2>
            </div>
        </div>



    @endif
-->



@endsection