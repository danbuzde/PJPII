@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
@endsection

@section('content')
<section>
    <div class="terms-container">
        <div class="terms-section">
                <h2>Regulamin sklepu internetowego </h2>
                
                <h3>§ 1</h3>
                <h4>Postanowienia wstępne</h4>
                            
                <p> 1.	Sklep internetowy ……………………….. (nazwa sklepu), dostępny pod adresem internetowym ………………………………, 
                    prowadzony jest przez.............. (imię i nazwisko) prowadzącego działalność gospodarczą pod firmą 
                    ......................, wpisaną do Centralnej Ewidencji i Informacji o Działalności Gospodarczej (CEIDG) 
                    prowadzonej przez ministra właściwego ds. gospodarki, NIP .............., REGON ..................... 
                </p>
                
                
                <h3> § 2 </h3>
                <h4> Definicje </h4>
                
                <p> 1.	Konsument - osoba fizyczna zawierająca ze Sprzedawcą umowę w ramach Sklepu, której przedmiot 
                    nie jest związany bezpośrednio z jej działalnością gospodarczą lub zawodową. 
                </p>              
                 <p>  2. Sprzedawca - osoba fizyczna prowadząca działalność gospodarczą pod firmą ......................, 
                    wpisaną do Centralnej Ewidencji i Informacji o Działalności Gospodarczej (CEIDG) prowadzonej przez 
                    ministra właściwego ds. gospodarki, NIP .............., REGON ......................
                </p> 
                <p>
                    3.	Klient - każdy podmiot dokonujący zakupów za pośrednictwem Sklepu.
                </p>
                <p>
                    4.	Przedsiębiorca - osoba fizyczna, osoba prawna i jednostka organizacyjna niebędąca osobą prawną, 
                    której odrębna ustawa przyznaje zdolność prawną, wykonująca we własnym imieniu działalność gospodarczą, 
                    która korzysta ze Sklepu.
                </p>
                <p>
                    5.	Sklep - sklep internetowy prowadzony przez Sprzedawcę pod adresem internetowym …………………..
                </p>
                <p>
                    6.	Umowa zawarta na odległość - umowa zawarta z Klientem w ramach zorganizowanego systemu zawierania 
                    umów na odległość (w ramach Sklepu), bez jednoczesnej fizycznej obecności stron, z wyłącznym wykorzystaniem
                     jednego lub większej liczby środków porozumiewania się na odległość do chwili zawarcia umowy włącznie.
                </p>
                <p>
                    7.	Regulamin - niniejszy regulamin Sklepu.
                </p>
                <p>
                    8.	Zamówienie - oświadczenie woli Klienta składane za pomocą Formularza Zamówienia i zmierzające bezpośrednio 
                    do zawarcia Umowy Sprzedaży Produktu lub Produktów ze Sprzedawcą.
                </p>
                <p>
                    9.	Konto - konto klienta w Sklepie, są w nim gromadzone są dane podane przez Klienta oraz informacje o
                     złożonych przez niego Zamówieniach w Sklepie.
                </p>
                <p>
                    10.	Formularz rejestracji - formularz dostępny w Sklepie, umożliwiający utworzenie Konta.
                </p>
                <p>
                    11.	Formularz zamówienia - interaktywny formularz dostępny w Sklepie umożliwiający złożenie Zamówienia, 
                    w szczególności poprzez dodanie Produktów do Koszyka oraz określenie warunków Umowy Sprzedaży, w tym 
                    sposobu dostawy i płatności.
                </p>
                <p>
                    12.	Koszyk – element oprogramowania Sklepu, w którym widoczne są wybrane przez Klienta Produkty do zakupu, 
                    a także istnieje możliwość ustalenia i modyfikacji danych Zamówienia, w szczególności ilości produktów.
                </p>
                <p>
                    13.	Produkt - dostępna w Sklepie rzecz ruchoma/usługa będąca przedmiotem Umowy Sprzedaży między Klientem a 
                    Sprzedawcą.
                </p>
                <p>
                    14.	Umowa Sprzedaży - umowa sprzedaży Produktu zawierana albo zawarta między Klientem a Sprzedawcą za 
                    pośrednictwem Sklepu internetowego. Przez Umowę Sprzedaży rozumie się też - stosowanie do cech Produktu - 
                    umowę o świadczenie usług i umowę o dzieło.
                </p>
                
                <h3>§ 3</h3>
                <h4>Kontakt ze Sklepem</h4>
                
                <p>
                    1.	Adres Sprzedawcy: …………..
                </p>
                <p>
                    2.	Adres e-mail Sprzedawcy: ………………..
                </p>
                <p>
                    3.	Numer telefonu Sprzedawcy: …………… .
                </p>
                <p>
                    4.	Numer fax Sprzedawcy …………………….
                </p>
                <p>
                    5.	Numer rachunku bankowego Sprzedawcy …………………………….
                </p>
                <p>
                    6.	Klient może porozumiewać się ze Sprzedawcą za pomocą adresów i numerów telefonów podanych w 
                    niniejszym paragrafie.
                </p>
                <p>
                    7.	Klient może porozumieć się telefonicznie ze Sprzedawcą w godzinach………….
                </p>
                
                <h3>§ 4</h3>
                <h4>Wymagania techniczne</h4>
                
                <p>
                    Do korzystania ze Sklepu, w tym przeglądania asortymentu Sklepu oraz składania zamówień na Produkty, 
                    niezbędne są: 
                </p>
                <p>
                    a.	urządzenie końcowe z dostępem do sieci Internet i przeglądarką internetową typu …………………………….,
                </p>
                <p>
                    b.	aktywne konto poczty elektronicznej (e-mail),
                </p>
                <p>
                    c.	włączona obsługa plików cookies,,
                </p>
                <p>
                    d.	zainstalowany program FlashPlayer.
                </p>
                
                <h3>§ 5</h3>
                <h4>Informacje ogólne</h4>
                
                <p>
                    1.	Sprzedawca w najszerszym dopuszczalnym przez prawo zakresie nie ponosi odpowiedzialności za 
                    zakłócenia w tym przerwy w funkcjonowaniu Sklepu spowodowane siłą wyższą, niedozwolonym działaniem 
                    osób trzecich lub niekompatybilnością Sklepu internetowego z infrastrukturą techniczną Klienta. 
                </p>
                <p>
                    2.	Przeglądanie asortymentu Sklepu nie wymaga zakładania Konta. Składanie zamówień przez Klienta 
                    na Produkty znajdujące się w asortymencie Sklepu możliwe jest albo po założeniu Konta zgodnie z 
                    postanowieniami § 6 Regulaminu albo przez podanie niezbędnych danych osobowych i adresowych 
                    umożliwiających realizację Zamówienia bez zakładania Konta. 
                </p>
                <p>
                    3.	 Ceny podane w Sklepie są podane w polskich złotych i są cenami brutto (uwzględniają podatek VAT).
                </p>
                

                
             
                
        </div> <!-- end of terms-section -->
    </div> <!-- end of terms-container -->
</section>

@endsection