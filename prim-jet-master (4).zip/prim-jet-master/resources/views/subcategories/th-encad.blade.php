@extends('layouts.master')
@section('title')
    Prim Jet Color - atramenty, lakiery
@endsection
@section('styles')
    <link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">  
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
    
    
@endsection

@section('content')

                <h2> Archiwalny barwnikowy do plotera ENCAD </h2>
                <p>  Atrament zapewnia 35 lat trwałości we wnętrzach </p>
            
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
                        @foreach($encad as $encadproducts) 
                                <tr>
                                    <td>
                                        <h4>{{ $encadproducts->title}}</h4>
                                    </td>
                                    <td>
                                        <h4>{{ $encadproducts->color}} </h4> 
                                    </td>
                                    <td>
                                        <h4>{{ $encadproducts->quantity}} </h4>
                                    </td>
                                    <td>
                                        <h4>{{ $encadproducts->price}}zł </h4>
                                    </td>
                                    <td> 
                                        <a href="{{ route('product.addToCart', ['id'=>$encad->id]) }}" class="order"> 
                                        <img class="add-cart-bg" src="img/icons/cart48.png"> <img class="add-cart-sm" src="img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
                        @endforeach   
            
                            </tbody>     
                        </table>
                    </div>

    <div class="my-pagin">
        {!! $encad_atraments -> links('vendor.pagination.bootstrap-4'); !!}
    </div>



</section>


@endsection

@section('scripts')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script>
      $(function () {
      $('.nav-tabs a:first').tab('show')
      })
</script>

@endsection