<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//this route will be redirected to controller action

Route::get('/', function () {
    return view('shop.home');
});

Route::get('/prods', [
    'uses' => 'ProductController@getIndexPiezo',
    'as' => 'product.prods'
]);

Route::get('/piezo', [
    'uses' => 'PageController@getPiezo',
    'as' => 'piezo'
]);

Route::get('/thermal-head', [
    'uses' => 'PageController@getThermalHead',
    'as' => 'thermal-head'
]);

Route::get('/subpiezo', [
    'uses' => 'PageController@getSubpiezo',
    'as' => 'subpiezo'
]);

/* Route::get('/th-encad', [
    'uses' => 'EncadprodController@getIndexTHencad',
    'as' => 'encadproducts.encad'
]); */

Route::get('/add-to-cart/{id}', [
    'uses' => 'ProductController@getAddToCart',
    'as' => 'product.addToCart'
]);
//id for informing which product to add

Route::get('/reduce/{id}', [
    'uses' => 'ProductController@getReduceByOne',
    'as' => 'product.reduceByOne'
]);

Route::get('/remove/{id}', [
    'uses' => 'ProductController@getRemoveItem',
    'as' => 'product.remove'
]);


Route::get('/shopping-cart', [
    'uses' => 'ProductController@getCart',
    'as' => 'product.shoppingCart'
]);


Route::get('/terms', [
    'uses' => 'PageController@getTerms',
    'as' => 'terms'
]);

Route::get('/delivery', [
    'uses' => 'PageController@getDelivery',
    'as' => 'delivery'
]);

Route::get('/home', [
    'uses' => 'PageController@getHome',
    'as' => 'home'
]);

Route::get('/about', [
    'uses' => 'PageController@getAbout',
    'as' => 'about'
]);

Route::get('/contact', [
    'uses' => 'PageController@getContact',
    'as' => 'contact'
]);

Route::post('/contact', [
    'uses' => 'PageController@postContact',
    'as' => 'contact'
]);

Route::get('/atraments', [
    'uses' => 'PageController@getAtraments',
    'as' => 'atraments'
]);

Route::get('/contactSuccess', [
    'uses' => 'PageController@getContactSuccess',
    'as' => 'contactSuccess'
]);

Route::get('/order', [
    'uses' => 'PageController@getOrder',
    'as' => 'order'
]);

Route::post('/order', [
    'uses' => 'PageController@postOrder',
    'as' => 'order'
]);

Route::get('prods/{cat}','ProductController@proCat');
/*
Route::get('/piezo', [
    'uses' => 'PageController@getPiezoPage',
    'as' => 'piezo'
]); */

