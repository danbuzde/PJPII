<footer> 

		<div class="copy"> &copy; Prim Jet Color 2017 </div> 
		<ul> 
			<li><a href="<?php echo e(route('terms')); ?>"> Regulamin   </a></li>
			<li><a href="<?php echo e(route('delivery')); ?>"> Wysyłka i Płatność   </a></li>
		</ul>

</footer>