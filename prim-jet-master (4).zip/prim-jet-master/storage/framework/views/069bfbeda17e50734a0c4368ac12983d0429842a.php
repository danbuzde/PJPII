<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section>

<div class="home-container">

		<div class="items">
			<span class="info">
                <h4> Atramenty i lakiery firmy Prim Jet Color </h4>
                <p> Firma Prim Jet Color Sp. z o.o. dostarcza wysokiej jakości atramenty, lakiery i akcesoria 
                do drukarek i ploterów użytkownikom indywidualnym, dystrybutorom przy pomocy usług 
                kurierskich np. GLS, Pocztex. </p>
                
                <p> Misją firmy Prim Jet Color Sp. z o.o. jest spełnienie aspiracji Klientów w rozwoju ich kreatywności jako nowoczesnych projektantów sztuki wizualnej, jak również pomoc dla firm, które pragną wypromować swoją markę używając naszych produktów. 
                Oferujemy usługi naszych pracowników i kooperujących firm nakierowane na perfekcję, mając na uwadze codzienną ochronę środowiska naszej planety jak również satysfakcję klientów.
                Tworzymy satysfakcję naszych Klientów. </p>
			</span>
		</div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>