<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section> 
	<div class="container d-flex justify-content-center">
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-7 col-xl-7">
				<h3> ATRAMENT BARWNIKOWY PLOTERY I DRUKARKI piezo DX </h3>
				<p> Atrament przeznaczony jest do mediów o pH powyżej 7: matowy, błyszczący kastingowy i 
                    fotograficzny powlekany papier, samoprzylepna błyszcząca folia winylowa, backlite 
                    oraz inne folie.</p>

				<p>Zastosowanie: Plakaty, grafika, bilboardy wewnątrz i (po pokryciu lakierem Top Coat) 
                    na zewnątrz pomieszczeń.</p>
                <p>Odporność na UV: 12 miesięcy po zastosowaniu lakieru Top Coat.</p>
			</div>
			<div class="col-sm-12 col-md-6 col-lg-5 col-xl-5 img-cont">
				<img class="atraments" src="img/epson.jpg" alt="atramenty">
			</div>
		</div>
    </div>
</section>
		<ol class="breadcrumb">
      		<li><a href="<?php echo e(url('prods/1')); ?>"> Do ploterów EPSON</a></li><br>
			<li><a href="<?php echo e(url('prods/2')); ?>"> Do ploterów EPSON z UV blokerem </a></li><br>
		</ol>
		
	</div> <!-- end of container  -->

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>