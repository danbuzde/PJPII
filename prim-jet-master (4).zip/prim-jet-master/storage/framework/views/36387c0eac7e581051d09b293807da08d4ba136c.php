<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">  
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                <h2> Archiwalny barwnikowy do plotera ENCAD </h2>
                <p>  Atrament zapewnia 35 lat trwałości we wnętrzach </p>
            
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
                        <?php $__currentLoopData = $encad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encadproducts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td>
                                        <h4><?php echo e($encadproducts->title); ?></h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($encadproducts->color); ?> </h4> 
                                    </td>
                                    <td>
                                        <h4><?php echo e($encadproducts->quantity); ?> </h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($encadproducts->price); ?>zł </h4>
                                    </td>
                                    <td> 
                                        <a href="<?php echo e(route('product.addToCart', ['id'=>$encad->id])); ?>" class="order"> 
                                        <img class="add-cart-bg" src="img/icons/cart48.png"> <img class="add-cart-sm" src="img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            
                            </tbody>     
                        </table>
                    </div>

    <div class="my-pagin">
        <?php echo $encad_atraments -> links('vendor.pagination.bootstrap-4');; ?>

    </div>



</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script>
      $(function () {
      $('.nav-tabs a:first').tab('show')
      })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>