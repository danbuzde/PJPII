<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section> 
	<div class="container d-flex ">
		
		<div class="row">
			<div class="col-sm-12 col-md-6 col-lg-5 col-xl-5 img-cont">
				<img class="atraments" src="img/atraments.jpg" alt="atramenty">
			</div>
			<div class="col-sm-12 col-md-6 col-lg-7 col-xl-7 atr-cont">
				<h3> Atramenty </h3>
				<p> Produkowane przez nas atramenty są bardzo wysokiej jakości. Ich parametry chemiczne i 
				fizyczne (m.in.  trwałość, barwa, półcienie, jaskrawość kolorów oraz ostrość konturów) są 
				dla każdej drukarki lub plotera kompatybilne z produktami firm OEM.</p>

				<p>Firma Prim Jet Color Sp. z o.o. ściśle współpracuje z Klientami w celu dostosowania 
				receptur poszczególnych atramentów do ich indywidualnych wymagań i potrzeb.</p>
			</div>
		</div>
		<ol class="breadcrumb">
      		<li><a href="<?php echo e(route('piezo')); ?>"> Atrament barwnikowy | Plotery i drukarki piezo DX</a></li><br>
			<li><a href="<?php echo e(route('thermal-head')); ?>"> Atrament barwnikowy | Plotery i drukarki z głowicą techniczną</a></li><br>
			<li><a href="<?php echo e(route('subpiezo')); ?>"> Atrament do sublimacji | Plotery i drukarki piezo DX</a></li>	<br>
		</ol>
		
	</div> <!-- end of container  -->

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>