<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="terms-container">
        <div class="terms-section">
            <h2>Dostawa i płatność </h2>

<p>Towar zamówiony w sklepie internetowym Prim Jet Color Sp. z o.o. dostarczamy kurierem.</p>


<h3>Na czas otrzymania przesyłki składa się: </h3>
<ul>
    <li>- czas realizacji zamówienia (wystawienie dokumentu sprzedaży, spakowanie paczki) </li>
    <li>- czas dostawy, zależny od wybranego sposobu dostarczenia (24 godz. kurier).</li>
</ul>

<h3>Wyróżniamy następujące terminy dostaw: </h3>

<ol> 
    <li>Towar wysyłamy zwykle w ciągu 24 godzin.</li>
    <li>Gdy towar dostępny jest w naszym magazynie. Zamówienie złożone i potwierdzone (w dni robocze 
        poniedziałek - piątek) jest realizowane tego samego dnia. Kupujący otrzyma paczkę następnego dnia 
        lub w poniedziałek w przypadku złożenia zamówienia w piątek. Dotyczy zamówień, w których jako formę 
        płatności wybrano "Pobranie". <br>
        Przy płatności za pobraniem istnieje możliwość otrzymania paczki następnego dnia do godziny 10:00 lub w 
        sobotę. Ta usługa jest dostępna tylko w wybranych rejonach kraju oraz wiąże się z dodatkową opłatą.
    </li>
    <li>W przypadku zaznaczenia płatności "Przelew na konto" czas realizacji zamówienia wydłuża się o czas 
        wpłynięcia przelewu na nasze konto i jego zaksięgowanie w programie sprzedaży. 
    </li>
</ol>
<p>Gdy towar nie jest aktualnie dostępny w naszym magazynie poinfurmujemy Klienta o przewidywanym terminie 
dostawy.</p>

<h3>Koszty transportu </h3>

<p>W zależności od wagi przesyłki oraz miejsca dostarczenia przesyłki opłaty wynoszą: </p>

<table> 
<h4>Teren całej Polski (dostarczane przez kuriera): 	</h4>		
	<tr> 
		<th>Waga przesyłki </th>
		<th> Opłata z VAT</th>
    </tr>
    <tr class="even"> 
		<td> Do 1 kg </th>
		<td> 23,50 zł </td>		
	</tr>
	<tr> 
		<td> od 1 kg  do 31,5 kg</th>
		<td> 25,00 zł </td>
	</tr>
</table>
 
<table> 
<h4>Usługi dodatkowe (niezależne od wartości towaru) dostępne są tylko w dostarczeniu w 
    wyznaczonych lokalizacjach: </h4>			
	<tr> 
		<th>Dopłaty </th>
		<th> Kwota z VAT</th>
    </tr>
    <tr class="even"> 
		<td> dostarczenie następnego dnia do 12.00 </th>
		<td> 30,00 zł </td>		
	</tr>
	<tr> 
		<td>doręczenie w sobotę </th>
		<td> 15,00 zł </td>
    </tr>
    <tr class="even"> 
		<td>doręczenie w niedzielę lub święto </th>
		<td> 30,00 zł </td>
    </tr>
    <tr> 
		<td>pobranie należności za towar </th>
		<td> 5,00 zł  + 1% wartości pobrania</td>
    </tr>
    <tr class="even"> 
		<td>zwrot dokumentów załączonych do przesyłki </th>
		<td> 10,00 zł</td>
    </tr>
    <tr> 
		<td>pisemne potwierdzenie dostawy </th>
		<td> 5,00 zł</td>
	</tr>
</table>


<h3>Sposoby płatności w sklepie Prim Jet Color Sp. z o.o.</h3>
<ul>
    <li> 
        <strong>- przelew-przedpłata - </strong> zamówienie zostanie zrealizowane, gdy pieniądze znajdą się na koncie bankowym 
        firmy Prim Jet Color Sp. z o.o. zostaną zaksięgowane (nie wymagamy przesłania potwierdzenia wpłaty 
        na nasze konto); przelew prosimy dokonać po otrzymaniu odpowiedniej informacji od handlowca 
        obsługującego zamówienie.
    </li>

    <li>
        <strong>- za pobraniem - </strong> w wypadku wysyłki spedycją należy zapłacić za towar w momencie odbioru przesyłki.
    </li>
    <li>
        <strong> - PayPal - </strong> płatności za towar mogą być realizowane za pośrednictwem systemu PayPal
    </li>
</ul>
        </div> <!-- end of terms-section -->
    </div> <!-- end of terms-container -->
</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>