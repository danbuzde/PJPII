<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
	<link rel="stylesheet" href="css/bootstrap/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section> 
	<div class="container d-flex ">
		
		<div class="row">
			<div class="col-sm-12 col-md-9 col-lg-9 col-xl-9">
				<h3> <span class="atr-header"> Atrament barwnikowy Plotery i drukarki </span> 
                        z głowicą termiczną 
                </h3>
				<p> Atrament przeznaczony jest do mediów o <strong> pH powyżej 7 </strong>: matowy, 
                błyszczący kastingowy i fotograficzny powlekany papier, samoprzylepna błyszcząca folia 
                winylowa, backlite oraz inne folie. </p>
                <p>Zastosowanie: Plakaty, grafika, bilboardy wewnątrz pomieszczeń.</p>
			</div>
		</div>
		<ol class="breadcrumb">
      		<li><a href="<?php echo e(route('encadproducts.encad')); ?>"> Archiwalny barwnikowy | Ploter ENCAD</a></li><br>
			<li><a href="#"> Barwnikowy | Ploter HP DESIGNJET </a></li><br>
			<li><a href="#"> Barwnikowy | Ploter CANON IPF </a></li>	<br>
		</ol>
		
	</div> <!-- end of container  -->

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>