<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="css/style.css" type="text/css"> 
	<link rel="stylesheet" href="css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="css/responsive.css" type="text/css"> 
 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section> 

	<div class="about-container">
		<div class="about-section">
<h3>O Firmie </h3>
<p> 
    Zadaniem firmy Prim Jet Color Sp. z o.o. jest dostarczanie produktów wysokiej jakości na dynamicznie rozwijający się rynek druku cyfrowego. Firma błyskawicznie reaguje na potrzeby Klientów, które pojawiają się w komputerowym wspomaganiu prac wydawniczych, grafice użytkowej, podczas druku przy pomocy drukarek i ploterów dużego formatu, wprowadzając nowe linie atramentów i specjalnych lakierów. 
</p>
<p> 
Firma Prim Jet Color Sp. z o.o. odpowiada na zapotrzebowanie na produkty wodoodporne i jednocześnie odporne na promieniowanie ultrafioletowe nadające się do ekspozycji na zewnątrz pomieszczeń poprzez wprowadzenie specjalnej linii atramentów pigmentowych oraz ekologicznych atramentów barwnikowych i pigmentowych na bazie rozpuszczalników (solwentowych).
Dostępne są także produkty takie jak kompatybilne kartridże do ploterów i drukarek dla szerokiej gamy różnych modeli.
</p>
<p> 
Produkowane przez nas atramenty są bardzo wysokiej jakości. Ich parametry chemiczne i fizyczne (m.in.  trwałość, barwa, półcienie, jaskrawość kolorów oraz ostrość konturów) są dla każdej drukarki lub plotera kompatybilne z produktami firm OEM.
</p>
<p> 
Firma Prim Jet Color Sp. z o.o.<span class="mark"> ściśle współpracuje z Klientami w celu dostosowania receptur poszczególnych
 atramentów do ich indywidualnych wymagań i potrzeb.</span> Ta filozofia działania zaowocowała konkretnymi decyzjami: opracowano i rozpoczęto produkcję nowych rodzajów atramentów, np. pigmentowych atramentów solwentowych odpornych na promieniowanie UV, przeznaczonych m.in. do wydruków wewnętrznych i zewnętrznych, do drukowania na opakowaniach towarów, czy też do nanoszenia kodów kreskowych.
</p>
<p> 
Firma Prim Jet Color Sp. z o.o. produkuje atramenty na bazie łagodnych rozpuszczalników, które stanowią przyszłość druku w technologii piezoelektrycznej. Są to ekologiczne atramenty solwentowe: barwnikowy (do ploterów m.in. Mimaki JV2/4, Mutoh Falcon i Falcon II, Roland HiFi Jet, Epson 9000/10000 i do ploterów o podobnej konstrukcji – Kodak, Agfa, Accuplot) oraz pigmentowy (mild solvent pigment) dwóch rodzajów – do mediów powlekanych i niepowlekanych, przeznaczony do ploterów z głowicą piezoelektryczną typu DX (Roland SolJet, SolJet 2, Mimaki JV2S, JV3, Mutoh Rockhoper oraz inne plotery dostosowane do atramentu solwentowego). 
Atramenty solwentowe służą do wykonywania nadruków na materiałach takich jak szkło, metal, tworzywa sztuczne, ceramika i tektura. Atramenty solwentowe oraz zmywające je płyny są produktami nie stwarzającymi zagrożenia dla zdrowia ich potencjalnych użytkowników, jak również nie wnoszą zagrożenia dla środowiska naturalnego i spełniają normy wymagane w Unii Europejskiej.
</p>
<p> 
Elastyczne podejście do każdego Klienta oraz najwyższa jakość produktów sprawiają, że firma Prim Jet Color Sp. z o.o.  jest liczącym się dostawcą atramentów w Polsce i za granicą.
</p>    

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>