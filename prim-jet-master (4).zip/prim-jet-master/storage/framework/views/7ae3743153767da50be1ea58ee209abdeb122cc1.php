<?php $__env->startSection('title'); ?>
    Prim Jet Color - atramenty, lakiery
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="/css/bootstrap/css/bootstrap.min.css" type="text/css">  
    <link rel="stylesheet" href="/css/style.css" type="text/css"> 
	<link rel="stylesheet" href="/css/normalize.css" type="text/css"> 
	<link rel="stylesheet" href="/css/interactions.css" type="text/css"> 
    <link rel="stylesheet" href="/css/responsive.css" type="text/css"> 
    
    
	

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- piezo content section was here -->
                <?php if(count($atraments)=="0"): ?>
				<h1>Nie znaleziono produktów z kategorii <?php echo e($catByUser); ?> </h1>
				<?php else: ?>
				<h2> <?php echo e($catByUser); ?> </h2>
                    
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
							
                        <?php $__currentLoopData = $atraments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_atr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
						
                                <tr>
                                    <td>
                                        <h4><?php echo e($product_atr->title); ?></h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atr->color); ?> </h4> 
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atr->quantity); ?> </h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atr->price); ?>zł </h4>
                                    </td>
									<td> 
                                        <a href="<?php echo e(route('product.addToCart', ['id'=>$product_atr->id])); ?>" class="order"> 
                                        <img class="add-cart-bg" src="/img/icons/cart48.png"> <img class="add-cart-sm" src="/img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>						
							
                            </tbody>     
                        </table>
                    </div>
           
<!--
    <div class="row">
    <article class="col-lg-12">
        <div class="tab-content">
            <div class="tab-pane fade" id="epsonUV">
                <h2> Do ploterów EPSON z UV blokerem</h2>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Rodzaj plotera</th>
                                    <th>Kolor</th>
                                    <th>Pojemność </th>
                                    <th>Cena</th>
                                    <th>Dodaj do koszyka </th>
                                </tr>
                            </thead>
    
                            <tbody>
                        <?php $__currentLoopData = $atraments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_atrUV): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <tr>
                                    <td>
                                        <h4><?php echo e($product_atrUV->title); ?></h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atrUV->color); ?> </h4> 
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atrUV->quantity); ?> </h4>
                                    </td>
                                    <td>
                                        <h4><?php echo e($product_atrUV->price); ?>zł </h4>
                                    </td>
                                    <td> 
                                        <a href="<?php echo e(route('product.addToCart', ['id'=>$product_atrUV->id])); ?>" class="order"> 
                                        <img class="add-cart-bg" src="img/icons/cart48.png"> <img class="add-cart-sm" src="img/icons/cart32.png"> 
                                        </a> 
                                    </td>
                                </tr> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            
                            </tbody>     
                        </table>
                    </div>
                </div>
            </div>
        </article>
    </div> -->

    <div class="my-pagin">
        <?php echo $atraments -> links('vendor.pagination.bootstrap-4');; ?>

    </div>



</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script>
      $(function () {
      $('.nav-tabs a:first').tab('show')
      })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>