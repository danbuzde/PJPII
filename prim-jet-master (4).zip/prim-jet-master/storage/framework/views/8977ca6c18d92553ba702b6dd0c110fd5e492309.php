<h3>Masz nową wiadomość z formularza kontaktowego</h3>

<div>
<?php echo e($bodyMessage); ?>


<p><?php echo e($name); ?></p>
<p>Numer telefonu: <?php echo e($phoneNumber); ?></p>
</div>

<p>Wysłano z adresu <?php echo e($email); ?></p>