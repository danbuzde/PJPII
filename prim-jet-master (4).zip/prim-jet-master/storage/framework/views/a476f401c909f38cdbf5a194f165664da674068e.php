<header>
    
	<div class="nav-container">
		<nav> 
			<ul class="main"> 
				<a href="<?php echo e(route('home')); ?>"><li> Home  </li></a>
				<a href="<?php echo e(route('about')); ?>"> <li>O firmie  </li></a>
				<li><a href="#" class="arrowlink" aria-haspopup="true"> Sklep </a>

					<ul> 
						<a href="#"><li>  Płynne laminaty </li></a> 
						<a href="#"><li> Lakiery podkładowe  </li></a>
						<a href="#"><li>  Płyny czyszczące </li></a> 
						<a href="<?php echo e(route('atraments')); ?>"><li>  Atramenty </li></a> 
					</ul>
				</li> 
				<a href="<?php echo e(route('contact')); ?>"><li> Kontakt  </li></a>
			</ul>
		</nav>
		
		<div class="search"> </div>
        <div class="cart"> 
            <a href="<?php echo e(route('product.shoppingCart')); ?>" class="cart-link"> 
                <div id="number" class="cart-number"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : ""); ?></div>
                 <img class="cart-bg" src="/img/icons/cart48.png"> <img class="cart-sm" src="/img/icons/cart32.png"> 
            </a>
		</div>
		<div class="logo"><a href="<?php echo e(route('home')); ?>"><strong> Prim Jet Color</strong> </br>
            <span> <a href="<?php echo e(route('atraments')); ?>"> atramenty </a>  |  <a href="#"> lakiery </a> </span> </a> 
        </div>
	</div>	
		
</header>